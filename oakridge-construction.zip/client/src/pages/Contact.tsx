import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { toast } from "sonner";
import { MapView } from "@/components/Map";

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Valid phone number is required"),
  projectType: z.string().min(1, "Please select a project type"),
  message: z.string().min(10, "Please provide some details about your project"),
});

export default function Contact() {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      projectType: "",
      message: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values);
    toast.success("Message sent successfully! We'll be in touch shortly.");
    form.reset();
  }

  return (
    <div className="flex flex-col w-full">
      {/* Header */}
      <section className="bg-secondary text-white py-20 relative overflow-hidden mt-20 md:mt-16">
        <div className="absolute inset-0 opacity-10 bg-[url('/hero-construction.jpg')] bg-cover bg-center grayscale"></div>
        <div className="container relative z-10">
          <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">Get In Touch</span>
          <h1 className="text-5xl md:text-7xl font-display font-bold uppercase leading-none mb-6">
            Start Your<br />Project
          </h1>
          <div className="w-24 h-2 bg-primary"></div>
        </div>
      </section>

      <section className="py-20 bg-background">
        <div className="container grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <div>
            <h2 className="text-3xl font-display font-bold uppercase text-secondary mb-8">
              Contact Information
            </h2>
            <p className="text-muted-foreground text-lg mb-12 leading-relaxed">
              Ready to discuss your construction needs? Fill out the form or contact us directly. We serve the greater Massachusetts area.
            </p>

            <div className="space-y-8 mb-12">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 flex items-center justify-center text-primary shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-display font-bold uppercase text-secondary mb-1">Office Location</h3>
                  <p className="text-muted-foreground">123 Construction Ave<br />Boston, MA 02110</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 flex items-center justify-center text-primary shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-display font-bold uppercase text-secondary mb-1">Phone</h3>
                  <p className="text-muted-foreground">(617) 555-0123</p>
                  <p className="text-xs text-muted-foreground mt-1">Mon-Fri, 8am - 6pm</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 flex items-center justify-center text-primary shrink-0">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-display font-bold uppercase text-secondary mb-1">Email</h3>
                  <p className="text-muted-foreground">info@oakridgeconstruction.com</p>
                </div>
              </div>
            </div>

            {/* Map Placeholder - Using MapView component */}
            <div className="h-[300px] w-full border border-border/60 grayscale hover:grayscale-0 transition-all duration-500">
               <MapView 
                className="w-full h-full"
                onMapReady={(map: google.maps.Map) => {
                  // Initialize map centered on Boston
                  map.setCenter({ lat: 42.3601, lng: -71.0589 });
                  map.setZoom(12);
                  
                  // Add marker for office
                  new google.maps.Marker({
                    position: { lat: 42.3601, lng: -71.0589 },
                    map: map,
                    title: "Oakridge Construction"
                  });
                }}
               />
            </div>
          </div>

          {/* Form */}
          <div className="bg-white p-8 md:p-12 border border-border/60 shadow-sm">
            <h2 className="text-2xl font-display font-bold uppercase text-secondary mb-6">
              Request a Quote
            </h2>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase text-xs font-bold tracking-wider text-secondary">Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} className="rounded-none border-border/60 focus:border-primary h-12 bg-gray-50" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="uppercase text-xs font-bold tracking-wider text-secondary">Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="john@example.com" {...field} className="rounded-none border-border/60 focus:border-primary h-12 bg-gray-50" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="uppercase text-xs font-bold tracking-wider text-secondary">Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="(555) 123-4567" {...field} className="rounded-none border-border/60 focus:border-primary h-12 bg-gray-50" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="projectType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase text-xs font-bold tracking-wider text-secondary">Project Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="rounded-none border-border/60 focus:border-primary h-12 bg-gray-50">
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="residential">Residential Construction</SelectItem>
                          <SelectItem value="commercial">Commercial Construction</SelectItem>
                          <SelectItem value="remodeling">Home Remodeling</SelectItem>
                          <SelectItem value="kitchen-bath">Kitchen & Bath</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase text-xs font-bold tracking-wider text-secondary">Project Details</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell us about your project goals, timeline, and budget..." 
                          className="rounded-none border-border/60 focus:border-primary min-h-[150px] bg-gray-50 resize-none" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full h-14 rounded-none bg-primary hover:bg-primary/90 text-white font-display text-lg tracking-wide uppercase shadow-md transition-all mt-4">
                  Send Message
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </section>
    </div>
  );
}
