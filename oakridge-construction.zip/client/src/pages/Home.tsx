import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Ruler, ShieldCheck, Clock, Hammer, Calendar, User } from "lucide-react";
import { Link } from "wouter";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { useEffect, useState } from "react";
import ReviewsSection from "@/components/ReviewsSection";
import { articles } from "@/data/articles";

export default function Home() {
  const { ref: whyUsRef, isVisible: whyUsVisible } = useScrollAnimation();
  const { ref: servicesRef, isVisible: servicesVisible } = useScrollAnimation();
  const { ref: projectsRef, isVisible: projectsVisible } = useScrollAnimation();
  const { ref: blogRef, isVisible: blogVisible } = useScrollAnimation();

  return (
    <div className="flex flex-col w-full">
      {/* Hero Section */}
      <section className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="/hero-construction.jpg" 
            alt="Construction Site" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-secondary/80 mix-blend-multiply" />
          <div className="absolute inset-0 bg-gradient-to-t from-secondary via-transparent to-transparent opacity-90" />
        </div>

        {/* Content */}
        <div className="container relative z-10 pt-20">
          <div className="max-w-4xl">
            <div className="inline-block mb-6 px-4 py-1 border border-primary/50 bg-primary/10 backdrop-blur-sm">
              <span className="text-primary font-mono text-sm tracking-[0.2em] uppercase font-bold">
                KRID STRUCT • MASSACHUSETTS
              </span>
            </div>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold text-white uppercase leading-[0.9] mb-8 tracking-tight">
              Building <span className="text-primary">Legacy</span><br />
              Through <span className="text-white">Precision</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-300 max-w-2xl mb-10 font-light leading-relaxed border-l-2 border-primary pl-6">
              Oakridge Construction delivers premium residential and commercial projects with an unwavering commitment to craftsmanship, safety, and structural integrity.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/contact">
                <Button className="h-14 px-8 rounded-none bg-primary hover:bg-primary/90 text-white font-display text-lg tracking-wide uppercase shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] hover:translate-y-[2px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,0.5)] transition-all border border-primary">
                  Request a Quote
                </Button>
              </Link>
              <Link href="/projects">
                <Button variant="outline" className="h-14 px-8 rounded-none border-white/30 text-white hover:bg-white hover:text-secondary font-display text-lg tracking-wide uppercase backdrop-blur-sm transition-all">
                  View Our Projects
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce hidden md:flex flex-col items-center gap-2 opacity-70">
          <span className="text-white text-[10px] font-mono uppercase tracking-widest">Scroll</span>
          <div className="w-[1px] h-12 bg-gradient-to-b from-primary to-transparent"></div>
        </div>
      </section>

      {/* Why Choose Us - Industrial Grid */}
      <section ref={whyUsRef} className="py-24 bg-background relative">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Section Header */}
            <div className={`lg:col-span-4 ${whyUsVisible ? 'animate-slide-left' : 'opacity-0'}`}>
              <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">Why Oakridge Construction</span>
              <h2 className="text-4xl md:text-5xl font-display font-bold uppercase leading-none mb-6 text-secondary">
                Engineered<br />For Excellence
              </h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                We don't just build structures; we engineer solutions. Our approach combines traditional craftsmanship with modern project management to ensure every detail meets rigorous standards.
              </p>
              <Link href="/about">
                <span className="inline-flex items-center gap-2 text-primary font-display uppercase tracking-wide hover:gap-4 transition-all cursor-pointer">
                  More About Us <ArrowRight className="w-4 h-4" />
                </span>
              </Link>
            </div>

            {/* Features Grid */}
            <div className={`lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6 ${whyUsVisible ? 'animate-slide-right' : 'opacity-0'}`}>
              {[
                {
                  icon: ShieldCheck,
                  title: "Licensed & Insured",
                  desc: "Fully compliant with Massachusetts building codes and safety regulations for your peace of mind."
                },
                {
                  icon: Ruler,
                  title: "Precision Build",
                  desc: "Exact execution of architectural plans with zero tolerance for structural compromise."
                },
                {
                  icon: Clock,
                  title: "On-Time Delivery",
                  desc: "Rigorous project management ensures deadlines are met without sacrificing quality."
                },
                {
                  icon: Hammer,
                  title: "Master Craftsmanship",
                  desc: "A team of seasoned veterans dedicated to the art of durable, high-end construction."
                }
              ].map((feature, idx) => (
                <div key={idx} className={`group p-8 border border-border/60 bg-white hover:border-primary/50 transition-all duration-300 relative overflow-hidden ${whyUsVisible ? 'animate-scale-in' : 'opacity-0'}`} style={{ animationDelay: `${idx * 100}ms` }}>
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <feature.icon className="w-24 h-24 text-primary" />
                  </div>
                  <feature.icon className="w-10 h-10 text-primary mb-6 relative z-10" />
                  <h3 className="text-xl font-display font-bold uppercase mb-3 relative z-10">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed relative z-10">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section ref={servicesRef} className="py-24 bg-secondary text-white relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'radial-gradient(#e5e7eb 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
        
        <div className="container relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div>
              <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">Our Expertise</span>
              <h2 className="text-4xl md:text-6xl font-display font-bold uppercase leading-none">
                Construction<br />Services
              </h2>
            </div>
            <Link href="/services">
              <Button variant="outline" className="rounded-none border-white/20 text-white hover:bg-primary hover:border-primary hover:text-white font-display tracking-wide uppercase h-12 px-8">
                View All Services
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-white/10 border border-white/10">
            {[
              {
                title: "Commercial Construction",
                desc: "Full-scale builds for retail, office, and industrial spaces.",
                image: "/service-commercial.jpg"
              },
              {
                title: "Luxury Remodeling",
                desc: "High-end renovations for kitchens, bathrooms, and interiors.",
                image: "/service-remodeling.jpg"
              },
              {
                title: "General Contracting",
                desc: "End-to-end project management from blueprint to handover.",
                image: "/project-featured.jpg"
              }
            ].map((service, idx) => (
              <div key={idx} className={`group relative h-[400px] overflow-hidden bg-secondary ${servicesVisible ? 'animate-slide-up' : 'opacity-0'}`} style={{ animationDelay: `${idx * 150}ms` }}>

                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-40 group-hover:scale-105 transition-all duration-700 grayscale group-hover:grayscale-0"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-secondary via-secondary/50 to-transparent" />
                
                <div className="absolute bottom-0 left-0 right-0 p-8 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                  <div className="w-12 h-[2px] bg-primary mb-6 origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-500 delay-100" />
                  <h3 className="text-2xl font-display font-bold uppercase mb-2">{service.title}</h3>
                  <p className="text-gray-400 text-sm mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100 max-w-[80%]">
                    {service.desc}
                  </p>
                  <span className="text-primary font-mono text-xs uppercase tracking-widest flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-200">
                    Learn More <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section ref={projectsRef} className="py-24 bg-background">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">Portfolio</span>
            <h2 className="text-4xl md:text-5xl font-display font-bold uppercase leading-none mb-6 text-secondary">
              Recent Work
            </h2>
            <p className="text-muted-foreground">
              A showcase of our commitment to quality across Massachusetts. From modern residential builds to complex commercial renovations.
            </p>
          </div>

          <div className={`grid grid-cols-1 md:grid-cols-2 gap-8 ${projectsVisible ? 'animate-slide-up' : 'opacity-0'}`}>
            <div className="group cursor-pointer">
              <div className="relative overflow-hidden aspect-[4/3] mb-6 border border-border/60">
                <img 
                  src="/project-featured.jpg" 
                  alt="Featured Project" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-primary/80 opacity-0 group-hover:opacity-90 transition-opacity duration-300 flex items-center justify-center">
                  <span className="text-white font-display text-2xl uppercase tracking-widest border-2 border-white px-6 py-3">View Project</span>
                </div>
              </div>
              <div className="flex justify-between items-start border-b border-border pb-4">
                <div>
                  <h3 className="text-2xl font-display font-bold uppercase text-secondary group-hover:text-primary transition-colors">The Highland Residence</h3>
                  <span className="text-muted-foreground font-mono text-sm">Newton, MA • Full Renovation</span>
                </div>
                <span className="text-primary font-technical text-xl font-bold">2024</span>
              </div>
            </div>

            <div className="group cursor-pointer md:mt-20">
              <div className="relative overflow-hidden aspect-[4/3] mb-6 border border-border/60">
                <img 
                  src="/service-commercial.jpg" 
                  alt="Featured Project" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-primary/80 opacity-0 group-hover:opacity-90 transition-opacity duration-300 flex items-center justify-center">
                  <span className="text-white font-display text-2xl uppercase tracking-widest border-2 border-white px-6 py-3">View Project</span>
                </div>
              </div>
              <div className="flex justify-between items-start border-b border-border pb-4">
                <div>
                  <h3 className="text-2xl font-display font-bold uppercase text-secondary group-hover:text-primary transition-colors">Tech Hub Office</h3>
                  <span className="text-muted-foreground font-mono text-sm">Cambridge, MA • Commercial Fit-out</span>
                </div>
                <span className="text-primary font-technical text-xl font-bold">2023</span>
              </div>
            </div>
          </div>

          <div className={`text-center mt-16 ${projectsVisible ? 'animate-scale-in' : 'opacity-0'}`} style={{ animationDelay: '300ms' }}>
            <Link href="/projects">
              <Button className="h-12 px-10 rounded-none bg-secondary text-white hover:bg-primary font-display tracking-wide uppercase transition-all">
                View All Projects
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <ReviewsSection />

      {/* Blog Section */}
      <section ref={blogRef} className="py-24 bg-secondary text-white">
        <div className="container">
          <div className="flex justify-between items-end mb-16">
            <div>
              <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">
                Latest Articles
              </span>
              <h2 className="text-4xl md:text-5xl font-display font-bold uppercase leading-none">
                Construction<br />Insights
              </h2>
            </div>
            <Link href="/blog">
              <Button variant="outline" className="rounded-none border-white/20 text-white hover:bg-primary hover:border-primary hover:text-white font-display tracking-wide uppercase h-12 px-8 hidden md:flex">
                View All Articles
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {articles.slice(0, 3).map((article, idx) => (
              <Link key={article.id} href={`/blog/${article.id}`}>
                <div className={`group cursor-pointer h-full flex flex-col ${idx === 0 ? 'animate-slide-left' : idx === 1 ? 'animate-slide-up' : 'animate-slide-right'}`}>
                  <div className="relative overflow-hidden aspect-video mb-6 border border-white/10 group-hover:border-primary transition-colors">
                    <img
                      src={article.image}
                      alt={article.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="inline-block px-3 py-1 bg-primary text-white text-xs font-mono uppercase tracking-widest">
                        {article.category}
                      </span>
                    </div>
                  </div>
                  <h3 className="font-display font-bold uppercase text-lg mb-3 group-hover:text-primary transition-colors line-clamp-2 flex-grow">
                    {article.title}
                  </h3>
                  <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                    {article.excerpt}
                  </p>
                  <div className="flex flex-wrap gap-4 text-xs text-gray-400 font-mono uppercase tracking-wide mt-auto pt-4 border-t border-white/10">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-primary" />
                      {new Date(article.date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-primary" />
                      {article.readTime} min
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-12 md:hidden">
            <Link href="/blog">
              <Button className="w-full rounded-none bg-primary text-white hover:bg-primary/90 font-display tracking-wide uppercase h-12">
                View All Articles
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-primary text-white relative overflow-hidden animate-slide-up">
        <div className="absolute inset-0 bg-[url('/hero-construction.jpg')] bg-cover bg-center mix-blend-multiply opacity-20 grayscale"></div>
        <div className="container relative z-10 text-center">
          <h2 className="text-4xl md:text-6xl font-display font-bold uppercase mb-8 max-w-4xl mx-auto leading-tight">
            Ready to Build Your Vision?
          </h2>
          <p className="text-white/90 text-lg max-w-2xl mx-auto mb-10 font-light">
            Contact Oakridge Construction today for a consultation. Let's discuss how we can bring your project to life with precision and quality.
          </p>
          <Link href="/contact">
            <Button className="h-16 px-12 rounded-none bg-white text-secondary hover:bg-secondary hover:text-white font-display text-xl tracking-wide uppercase shadow-lg transition-all border-2 border-transparent hover:border-white">
              Start Your Project
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
