import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Link } from "wouter";

export default function Projects() {
  const [filter, setFilter] = useState("all");

  const projects = [
    {
      id: 1,
      title: "The Highland Residence",
      category: "residential",
      location: "Newton, MA",
      year: "2024",
      image: "/project-featured.jpg",
      desc: "Complete gut renovation of a 1920s colonial."
    },
    {
      id: 2,
      title: "Tech Hub Office",
      category: "commercial",
      location: "Cambridge, MA",
      year: "2023",
      image: "/service-commercial.jpg",
      desc: "Modern open-plan office fit-out for a software startup."
    },
    {
      id: 3,
      title: "Beacon Hill Kitchen",
      category: "remodeling",
      location: "Boston, MA",
      year: "2023",
      image: "/service-remodeling.jpg",
      desc: "Luxury kitchen expansion with custom millwork."
    },
    {
      id: 4,
      title: "Seaport Retail Space",
      category: "commercial",
      location: "Boston, MA",
      year: "2024",
      image: "/hero-construction.jpg",
      desc: "High-end retail build-out with custom lighting."
    },
    {
      id: 5,
      title: "Brookline Addition",
      category: "residential",
      location: "Brookline, MA",
      year: "2022",
      image: "/project-featured.jpg",
      desc: "Two-story addition adding 1,200 sq ft of living space."
    },
    {
      id: 6,
      title: "Loft Conversion",
      category: "remodeling",
      location: "Somerville, MA",
      year: "2023",
      image: "/service-remodeling.jpg",
      desc: "Industrial loft conversion with exposed brick and beams."
    }
  ];

  const filteredProjects = filter === "all" 
    ? projects 
    : projects.filter(p => p.category === filter);

  const categories = [
    { id: "all", label: "All Projects" },
    { id: "residential", label: "Residential" },
    { id: "commercial", label: "Commercial" },
    { id: "remodeling", label: "Remodeling" }
  ];

  return (
    <div className="flex flex-col w-full">
      {/* Header */}
      <section className="bg-secondary text-white py-20 relative overflow-hidden mt-20 md:mt-16">
        <div className="absolute inset-0 opacity-10 bg-[url('/project-featured.jpg')] bg-cover bg-center grayscale"></div>
        <div className="container relative z-10">
          <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">Our Portfolio</span>
          <h1 className="text-5xl md:text-7xl font-display font-bold uppercase leading-none mb-6">
            Selected<br />Works
          </h1>
          <div className="w-24 h-2 bg-primary"></div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-20 bg-background min-h-screen">
        <div className="container">
          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-12 justify-center md:justify-start">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setFilter(cat.id)}
                className={`px-6 py-2 text-sm font-display uppercase tracking-wider transition-all border ${
                  filter === cat.id 
                    ? "bg-primary border-primary text-white" 
                    : "bg-transparent border-border text-muted-foreground hover:border-primary hover:text-primary"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <div key={project.id} className="group cursor-pointer">
                <div className="relative overflow-hidden aspect-[4/3] mb-4 border border-border/60 bg-secondary">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-90 group-hover:opacity-100"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-secondary/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                    <p className="text-white text-sm mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75">
                      {project.desc}
                    </p>
                  </div>
                </div>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-display font-bold uppercase text-secondary group-hover:text-primary transition-colors">
                      {project.title}
                    </h3>
                    <span className="text-muted-foreground font-mono text-xs uppercase tracking-wider">
                      {project.location}
                    </span>
                  </div>
                  <span className="text-primary font-technical text-lg font-bold opacity-50 group-hover:opacity-100 transition-opacity">
                    {project.year}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
