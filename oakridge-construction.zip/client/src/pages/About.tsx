import { Button } from "@/components/ui/button";
import { Check, HardHat, Award, Users } from "lucide-react";
import { Link } from "wouter";
import { useCountUp, useScrollAnimation } from "@/hooks/useScrollAnimation";

function StatCounter({ number, label, suffix = "+" }: { number: number; label: string; suffix?: string }) {
  const { ref, count } = useCountUp(number, 2000);
  return (
    <div ref={ref} className="p-4 animate-scale-in">
      <div className="text-5xl md:text-6xl font-technical font-bold text-primary mb-2">
        {count}{suffix}
      </div>
      <div className="text-sm font-mono uppercase tracking-widest text-gray-400">{label}</div>
    </div>
  );
}

export default function About() {
  return (
    <div className="flex flex-col w-full">
      {/* Header */}
      <section className="bg-secondary text-white py-20 relative overflow-hidden mt-20 md:mt-16">
        <div className="absolute inset-0 opacity-10 bg-[url('/hero-construction.jpg')] bg-cover bg-center grayscale"></div>
        <div className="container relative z-10">
          <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">Who We Are</span>
          <h1 className="text-5xl md:text-7xl font-display font-bold uppercase leading-none mb-6">
            Oakridge Construction<br />Built on Integrity
          </h1>
          <div className="w-24 h-2 bg-primary"></div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 bg-background">
        <div className="container grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-display font-bold uppercase text-secondary mb-6">
              Our Story
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              Founded in 2005, Oakridge Construction began with a simple mission: to bring a higher standard of craftsmanship and professionalism to the Massachusetts construction industry.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              What started as a small team of dedicated carpenters has grown into a premier full-service construction firm. We've built our reputation project by project, treating every home and commercial space as if it were our own. Our philosophy is grounded in transparency, precision, and an unwavering commitment to safety.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
              {[
                "Licensed & Insured in MA",
                "OSHA Certified Team",
                "20+ Years Experience",
                "Satisfaction Guaranteed"
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Check className="w-4 h-4 text-primary" />
                  </div>
                  <span className="font-medium text-secondary">{item}</span>
                </div>
              ))}
            </div>

            <Link href="/contact">
              <Button className="h-12 px-8 rounded-none bg-primary text-white hover:bg-primary/90 font-display tracking-wide uppercase transition-all">
                Work With Us
              </Button>
            </Link>
          </div>

          <div className="relative">
            <div className="aspect-[4/5] bg-gray-200 relative z-10 border-8 border-white shadow-xl">
              <img 
                src="/service-commercial.jpg" 
                alt="Oakridge Team at Work" 
                className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
              />
            </div>
            <div className="absolute -bottom-10 -left-10 w-2/3 aspect-square bg-primary/10 -z-0"></div>
            <div className="absolute -top-10 -right-10 w-2/3 aspect-square border-2 border-primary/20 -z-0"></div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-gray-50 border-y border-border/60">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-display font-bold uppercase text-secondary mb-6">
              Core Values
            </h2>
            <p className="text-muted-foreground">
              Every nail driven and every beam placed is guided by the principles that define our company culture.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: HardHat,
                title: "Safety First",
                desc: "We maintain rigorous safety protocols to protect our team, our clients, and your property at all times."
              },
              {
                icon: Award,
                title: "Quality Assurance",
                desc: "We don't cut corners. We use premium materials and proven techniques to ensure lasting results."
              },
              {
                icon: Users,
                title: "Client Partnership",
                desc: "We believe in clear communication and collaboration. You are part of the team from day one."
              }
            ].map((value, idx) => (
              <div key={idx} className="bg-white p-10 border border-border/60 text-center hover:border-primary/50 transition-colors group">
                <div className="w-16 h-16 bg-secondary text-white mx-auto flex items-center justify-center mb-6 group-hover:bg-primary transition-colors">
                  <value.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-display font-bold uppercase mb-4 text-secondary">{value.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Stats */}
      <section className="py-24 bg-secondary text-white">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x divide-white/10">
            <StatCounter number={19} label="Years in Business" />
            <StatCounter number={500} label="Projects Completed" />
            <StatCounter number={35} label="Team Members" />
            <StatCounter number={100} label="Client Satisfaction" suffix="%" />
          </div>
        </div>
      </section>
    </div>
  );
}
