import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { articles } from "@/data/articles";
import { ArrowLeft, Calendar, User, Clock, Share2 } from "lucide-react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

export default function BlogPost() {
  const { id } = useParams<{ id: string }>();
  const article = articles.find(a => a.id === id);
  const { ref, isVisible } = useScrollAnimation();

  if (!article) {
    return (
      <div className="flex flex-col w-full min-h-screen">
        <section className="flex-1 flex items-center justify-center bg-background">
          <div className="container text-center">
            <h1 className="text-4xl font-display font-bold uppercase mb-4 text-secondary">
              Article Not Found
            </h1>
            <p className="text-muted-foreground mb-8">
              The article you're looking for doesn't exist.
            </p>
            <Link href="/blog">
              <Button className="bg-primary text-white hover:bg-primary/90 font-display tracking-wide uppercase">
                Back to Blog
              </Button>
            </Link>
          </div>
        </section>
      </div>
    );
  }

  const relatedArticles = articles
    .filter(a => a.category === article.category && a.id !== article.id)
    .slice(0, 3);

  return (
    <div className="flex flex-col w-full">
      {/* Header */}
      <section className="bg-secondary text-white py-16 relative overflow-hidden mt-20 md:mt-16">
        <div className="absolute inset-0 opacity-10 bg-[url('/hero-construction.jpg')] bg-cover bg-center grayscale"></div>
        <div className="container relative z-10">
          <Link href="/blog">
            <span className="inline-flex items-center gap-2 text-primary font-mono text-sm uppercase tracking-widest mb-6 hover:gap-3 transition-all cursor-pointer">
              <ArrowLeft className="w-4 h-4" />
              Back to Blog
            </span>
          </Link>
          <h1 className="text-4xl md:text-6xl font-display font-bold uppercase leading-tight mb-6">
            {article.title}
          </h1>
          <div className="flex flex-wrap gap-6 text-sm text-gray-300 font-mono uppercase tracking-wide">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" />
              {new Date(article.date).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-primary" />
              {article.author}
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" />
              {article.readTime} min read
            </div>
          </div>
        </div>
      </section>

      {/* Featured Image */}
      <section className="bg-background py-12">
        <div className="container">
          <div className="relative overflow-hidden aspect-video border border-border/60">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Article Content */}
      <section ref={ref} className="py-20 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className={`lg:col-span-2 ${isVisible ? 'animate-slide-right' : 'opacity-0'}`}>
              <div className="prose prose-lg max-w-none">
                <div
                  className="text-muted-foreground leading-relaxed space-y-6"
                  dangerouslySetInnerHTML={{ __html: article.content }}
                />
              </div>

              {/* Share Section */}
              <div className="mt-12 pt-8 border-t border-border/40">
                <h3 className="text-lg font-display font-bold uppercase mb-4 text-secondary">
                  Share This Article
                </h3>
                <div className="flex gap-4">
                  <button className="w-12 h-12 flex items-center justify-center border border-border/60 hover:bg-primary hover:border-primary hover:text-white transition-all">
                    <span className="text-xs font-bold">f</span>
                  </button>
                  <button className="w-12 h-12 flex items-center justify-center border border-border/60 hover:bg-primary hover:border-primary hover:text-white transition-all">
                    <span className="text-xs font-bold">𝕏</span>
                  </button>
                  <button className="w-12 h-12 flex items-center justify-center border border-border/60 hover:bg-primary hover:border-primary hover:text-white transition-all">
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className={`lg:col-span-1 ${isVisible ? 'animate-slide-left' : 'opacity-0'}`}>
              {/* Author Card */}
              <div className="p-8 border border-border/60 bg-white mb-8">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center text-white font-display font-bold text-2xl mb-4">
                  {article.author.charAt(0)}
                </div>
                <h3 className="font-display font-bold text-secondary uppercase mb-2">
                  {article.author}
                </h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Expert contributor to Oakridge Construction's knowledge hub, sharing insights on construction, design, and best practices.
                </p>
              </div>

              {/* CTA Box */}
              <div className="p-8 border border-primary/50 bg-primary/5 mb-8">
                <h3 className="font-display font-bold text-secondary uppercase mb-4">
                  Ready to Build?
                </h3>
                <p className="text-muted-foreground text-sm mb-6">
                  Let's discuss how Oakridge Construction can bring your vision to life.
                </p>
                <Link href="/contact">
                  <Button className="w-full bg-primary text-white hover:bg-primary/90 font-display tracking-wide uppercase">
                    Get a Quote
                  </Button>
                </Link>
              </div>

              {/* Related Articles */}
              {relatedArticles.length > 0 && (
                <div>
                  <h3 className="font-display font-bold text-secondary uppercase mb-6">
                    Related Articles
                  </h3>
                  <div className="space-y-4">
                    {relatedArticles.map(related => (
                      <Link key={related.id} href={`/blog/${related.id}`}>
                        <div className="p-4 border border-border/60 hover:border-primary/50 transition-colors group cursor-pointer">
                          <h4 className="font-display font-bold text-sm uppercase text-secondary group-hover:text-primary transition-colors mb-2 line-clamp-2">
                            {related.title}
                          </h4>
                          <p className="text-xs text-muted-foreground font-mono">
                            {new Date(related.date).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric'
                            })}
                          </p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* More Articles */}
      <section className="py-20 bg-secondary text-white">
        <div className="container">
          <h2 className="text-4xl font-display font-bold uppercase mb-12 text-center">
            More Articles
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {articles
              .filter(a => a.id !== article.id)
              .slice(0, 3)
              .map((post, idx) => (
                <Link key={post.id} href={`/blog/${post.id}`}>
                  <div className={`group cursor-pointer ${isVisible ? 'animate-scale-in' : 'opacity-0'}`} style={{ animationDelay: `${idx * 100}ms` }}>
                    <div className="relative overflow-hidden aspect-video mb-4 border border-white/10 group-hover:border-primary transition-colors">
                      <img
                        src={post.image}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <h3 className="font-display font-bold uppercase text-lg mb-2 group-hover:text-primary transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center gap-2 text-primary font-mono text-xs uppercase tracking-widest group-hover:gap-3 transition-all">
                      Read More
                      <span>→</span>
                    </div>
                  </div>
                </Link>
              ))}
          </div>
        </div>
      </section>
    </div>
  );
}
