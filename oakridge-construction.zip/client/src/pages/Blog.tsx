import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { articles, categories } from "@/data/articles";
import { ArrowRight, Calendar, User, Clock } from "lucide-react";
import { useState } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

export default function Blog() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { ref, isVisible } = useScrollAnimation();

  const filteredArticles = selectedCategory
    ? articles.filter(a => a.category === selectedCategory)
    : articles;

  return (
    <div className="flex flex-col w-full">
      {/* Header */}
      <section className="bg-secondary text-white py-20 relative overflow-hidden mt-20 md:mt-16">
        <div className="absolute inset-0 opacity-10 bg-[url('/hero-construction.jpg')] bg-cover bg-center grayscale"></div>
        <div className="container relative z-10">
          <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">Knowledge Hub</span>
          <h1 className="text-5xl md:text-7xl font-display font-bold uppercase leading-none mb-6">
            Construction<br />Insights & Tips
          </h1>
          <div className="w-24 h-2 bg-primary"></div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
            {/* Sidebar - Categories */}
            <div className="lg:col-span-1">
              <div className={`sticky top-32 ${isVisible ? 'animate-slide-left' : 'opacity-0'}`}>
                <h3 className="text-xl font-display font-bold uppercase mb-6 text-secondary">
                  Categories
                </h3>
                <div className="space-y-3">
                  <button
                    onClick={() => setSelectedCategory(null)}
                    className={`block w-full text-left px-4 py-3 border border-border/60 transition-all duration-300 font-mono text-sm uppercase tracking-wide ${
                      selectedCategory === null
                        ? 'bg-primary text-white border-primary'
                        : 'bg-white hover:border-primary/50'
                    }`}
                  >
                    All Articles
                  </button>
                  {categories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`block w-full text-left px-4 py-3 border border-border/60 transition-all duration-300 font-mono text-sm uppercase tracking-wide ${
                        selectedCategory === cat
                          ? 'bg-primary text-white border-primary'
                          : 'bg-white hover:border-primary/50'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Articles Grid */}
            <div className="lg:col-span-3">
              {filteredArticles.length > 0 ? (
                <div className="space-y-8">
                  {filteredArticles.map((article, idx) => (
                    <Link key={article.id} href={`/blog/${article.id}`}>
                      <div
                        className={`group grid grid-cols-1 md:grid-cols-3 gap-6 pb-8 border-b border-border/40 hover:border-primary/50 transition-all duration-300 cursor-pointer ${
                          isVisible ? 'animate-slide-up' : 'opacity-0'
                        }`}
                        style={{ animationDelay: `${idx * 100}ms` }}
                      >
                        {/* Image */}
                        <div className="md:col-span-1 relative overflow-hidden aspect-[4/3] border border-border/60 group-hover:border-primary/50 transition-colors">
                          <img
                            src={article.image}
                            alt={article.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute top-4 left-4">
                            <span className="inline-block px-3 py-1 bg-primary text-white text-xs font-mono uppercase tracking-widest">
                              {article.category}
                            </span>
                          </div>
                        </div>

                        {/* Content */}
                        <div className="md:col-span-2 flex flex-col justify-between">
                          <div>
                            <h2 className="text-2xl font-display font-bold uppercase mb-3 text-secondary group-hover:text-primary transition-colors">
                              {article.title}
                            </h2>
                            <p className="text-muted-foreground mb-4 leading-relaxed">
                              {article.excerpt}
                            </p>
                          </div>

                          {/* Meta Info */}
                          <div className="flex flex-wrap gap-6 text-sm text-muted-foreground font-mono uppercase tracking-wide">
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4 text-primary" />
                              {new Date(article.date).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric'
                              })}
                            </div>
                            <div className="flex items-center gap-2">
                              <User className="w-4 h-4 text-primary" />
                              {article.author}
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-primary" />
                              {article.readTime} min read
                            </div>
                          </div>

                          {/* Read More */}
                          <div className="mt-4 flex items-center gap-2 text-primary font-display font-bold uppercase tracking-wide group-hover:gap-3 transition-all">
                            Read Article
                            <ArrowRight className="w-4 h-4" />
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground text-lg">
                    No articles found in this category.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary text-white">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-display font-bold uppercase mb-6">
            Ready to Start Your Project?
          </h2>
          <Link href="/contact">
            <Button className="bg-white text-primary hover:bg-gray-100 font-display tracking-wide uppercase h-12 px-8 rounded-none">
              Get a Free Quote
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
