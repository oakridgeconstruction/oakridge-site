import { Button } from "@/components/ui/button";
import { ArrowRight, Hammer, PaintBucket, Ruler, Home, Building2, Layers } from "lucide-react";
import { Link } from "wouter";

export default function Services() {
  const services = [
    {
      id: "remodeling",
      title: "Home Remodeling",
      icon: Home,
      desc: "Transform your existing space into your dream home. We handle everything from structural changes to finishing touches.",
      features: ["Open Concept Layouts", "Basement Finishing", "Attic Conversions", "Room Additions"],
      image: "/service-remodeling.jpg"
    },
    {
      id: "kitchen-bath",
      title: "Kitchen & Bath",
      icon: Layers,
      desc: "Modernize the most important rooms in your house. Custom cabinetry, premium fixtures, and expert tile work.",
      features: ["Custom Cabinetry", "Stone Countertops", "Walk-in Showers", "Lighting Design"],
      image: "/project-featured.jpg"
    },
    {
      id: "commercial",
      title: "Commercial Build",
      icon: Building2,
      desc: "Reliable construction services for businesses. Office fit-outs, retail spaces, and industrial modifications.",
      features: ["Office Build-outs", "Retail Renovations", "Code Compliance", "Project Management"],
      image: "/service-commercial.jpg"
    },
    {
      id: "flooring",
      title: "Flooring & Carpentry",
      icon: Ruler,
      desc: "Exquisite woodwork and durable flooring solutions. From hardwood installation to custom built-ins.",
      features: ["Hardwood Installation", "Custom Trim & Molding", "Deck Building", "Staircases"],
      image: "/hero-construction.jpg"
    },
    {
      id: "painting",
      title: "Painting & Drywall",
      icon: PaintBucket,
      desc: "Flawless finishes for interior and exterior surfaces. Professional preparation and high-quality paints.",
      features: ["Interior/Exterior Painting", "Drywall Installation", "Plaster Repair", "Wallpaper Removal"],
      image: "/service-remodeling.jpg"
    },
    {
      id: "renovations",
      title: "Complete Renovations",
      icon: Hammer,
      desc: "Full-scale gut renovations for older homes. We modernize systems while preserving historic charm.",
      features: ["Gut Renovations", "Historic Restoration", "System Upgrades", "Structural Repair"],
      image: "/project-featured.jpg"
    }
  ];

  return (
    <div className="flex flex-col w-full">
      {/* Header */}
      <section className="bg-secondary text-white py-20 relative overflow-hidden mt-20 md:mt-16">
        <div className="absolute inset-0 opacity-10 bg-[url('/service-commercial.jpg')] bg-cover bg-center grayscale"></div>
        <div className="container relative z-10">
          <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">What We Do</span>
          <h1 className="text-5xl md:text-7xl font-display font-bold uppercase leading-none mb-6">
            Expert<br />Services
          </h1>
          <div className="w-24 h-2 bg-primary"></div>
        </div>
      </section>

      {/* Services List */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 gap-16">
            {services.map((service, idx) => (
              <div key={service.id} className={`flex flex-col ${idx % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-12 items-center group`}>
                {/* Image Side */}
                <div className="w-full lg:w-1/2 relative">
                  <div className="aspect-[4/3] overflow-hidden border border-border/60 relative z-10">
                    <img 
                      src={service.image} 
                      alt={service.title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 grayscale group-hover:grayscale-0"
                    />
                  </div>
                  <div className={`absolute -bottom-6 -right-6 w-full h-full border-2 border-primary/20 -z-0 hidden lg:block transition-transform duration-500 group-hover:translate-x-2 group-hover:translate-y-2 ${idx % 2 !== 0 ? 'left-6 right-auto' : ''}`}></div>
                </div>

                {/* Content Side */}
                <div className="w-full lg:w-1/2">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-primary/10 flex items-center justify-center text-primary">
                      <service.icon className="w-6 h-6" />
                    </div>
                    <h2 className="text-3xl md:text-4xl font-display font-bold uppercase text-secondary">
                      {service.title}
                    </h2>
                  </div>
                  
                  <p className="text-muted-foreground text-lg leading-relaxed mb-8 border-l-2 border-primary/30 pl-6">
                    {service.desc}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                    {service.features.map((feature, fIdx) => (
                      <div key={fIdx} className="flex items-center gap-2 text-sm font-medium text-secondary">
                        <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                        {feature}
                      </div>
                    ))}
                  </div>

                  <Link href="/contact">
                    <Button variant="outline" className="h-12 px-8 rounded-none border-secondary text-secondary hover:bg-secondary hover:text-white font-display tracking-wide uppercase transition-all">
                      Get a Quote
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-primary text-white text-center">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-display font-bold uppercase mb-8">
            Have a Custom Project?
          </h2>
          <p className="text-white/90 text-lg max-w-2xl mx-auto mb-10">
            We love a challenge. If you don't see exactly what you're looking for, reach out to us. We can likely build it.
          </p>
          <Link href="/contact">
            <Button className="h-14 px-10 rounded-none bg-white text-secondary hover:bg-secondary hover:text-white font-display text-lg tracking-wide uppercase shadow-lg transition-all">
              Contact Us Today
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
