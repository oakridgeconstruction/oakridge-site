import { Star } from "lucide-react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

interface Review {
  name: string;
  role: string;
  rating: number;
  text: string;
  avatar: string;
  initials: string;
}

const reviews: Review[] = [
  {
    name: "Sarah Mitchell",
    role: "Homeowner, Newton MA",
    rating: 5,
    text: "Oakridge Construction transformed our 1970s home into a modern masterpiece. The attention to detail and professionalism were exceptional. Highly recommend!",
    avatar: "SM",
    initials: "SM"
  },
  {
    name: "James Chen",
    role: "Real Estate Developer",
    rating: 5,
    text: "Working with Oakridge Construction on our commercial project was seamless. They delivered on time, on budget, and with impeccable quality. True professionals.",
    avatar: "JC",
    initials: "JC"
  },
  {
    name: "Michelle Rodriguez",
    role: "Business Owner, Cambridge MA",
    rating: 5,
    text: "Our office renovation exceeded all expectations. The team was communicative, respectful of our workspace, and incredibly skilled. Worth every penny.",
    avatar: "MR",
    initials: "MR"
  },
  {
    name: "David Thompson",
    role: "Property Manager",
    rating: 5,
    text: "I've worked with many contractors over the years. Oakridge Construction stands out for their reliability, craftsmanship, and commitment to safety. Best in the business.",
    avatar: "DT",
    initials: "DT"
  }
];

export default function ReviewsSection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section ref={ref} className="py-24 bg-background">
      <div className="container">
        {/* Section Header */}
        <div className={`text-center mb-16 ${isVisible ? 'animate-slide-up' : 'opacity-0'}`}>
          <span className="text-primary font-mono text-sm tracking-widest uppercase block mb-4">
            Client Testimonials
          </span>
          <h2 className="text-4xl md:text-5xl font-display font-bold uppercase mb-6 text-secondary">
            Trusted by Hundreds<br />of Satisfied Clients
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            See what our clients have to say about their experience working with Oakridge Construction.
          </p>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {reviews.map((review, idx) => (
            <div
              key={idx}
              className={`group p-8 border border-border/60 bg-white hover:border-primary/50 transition-all duration-300 ${
                isVisible ? 'animate-scale-in' : 'opacity-0'
              }`}
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: review.rating }).map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 fill-primary text-primary"
                  />
                ))}
              </div>

              {/* Review Text */}
              <p className="text-muted-foreground mb-6 leading-relaxed italic">
                "{review.text}"
              </p>

              {/* Author Info */}
              <div className="flex items-center gap-4 pt-6 border-t border-border/40">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center text-white font-display font-bold text-lg">
                  {review.initials}
                </div>
                <div>
                  <h4 className="font-display font-bold text-secondary uppercase tracking-wide">
                    {review.name}
                  </h4>
                  <p className="text-muted-foreground text-sm font-mono">
                    {review.role}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-20 pt-20 border-t border-border/40">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-technical font-bold text-primary mb-2">
                4.9/5
              </div>
              <p className="text-muted-foreground font-mono text-sm uppercase tracking-widest">
                Average Rating
              </p>
            </div>
            <div>
              <div className="text-4xl font-technical font-bold text-primary mb-2">
                500+
              </div>
              <p className="text-muted-foreground font-mono text-sm uppercase tracking-widest">
                Projects Completed
              </p>
            </div>
            <div>
              <div className="text-4xl font-technical font-bold text-primary mb-2">
                100%
              </div>
              <p className="text-muted-foreground font-mono text-sm uppercase tracking-widest">
                Client Satisfaction
              </p>
            </div>
            <div>
              <div className="text-4xl font-technical font-bold text-primary mb-2">
                19+
              </div>
              <p className="text-muted-foreground font-mono text-sm uppercase tracking-widest">
                Years Trusted
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
