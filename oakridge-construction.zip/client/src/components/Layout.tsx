import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Menu, X, Phone, MapPin, Mail, Instagram, Linkedin, Facebook } from "lucide-react";
import { useState, useEffect } from "react";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "Services", href: "/services" },
    { name: "Projects", href: "/projects" },
    { name: "Blog", href: "/blog" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans selection:bg-primary selection:text-primary-foreground">
      {/* Top Bar - Industrial Detail */}
      <div className="bg-secondary text-secondary-foreground py-2 text-xs font-mono tracking-wider hidden md:block border-b border-white/10">
        <div className="container flex justify-between items-center">
          <div className="flex gap-6">
            <span className="flex items-center gap-2">
              <MapPin className="w-3 h-3 text-primary" />
              SERVING MASSACHUSETTS
            </span>
            <span className="flex items-center gap-2">
              <Phone className="w-3 h-3 text-primary" />
              (617) 555-0123
            </span>
          </div>
          <div className="flex gap-4">
            <a href="#" className="hover:text-primary transition-colors">LINKEDIN</a>
            <a href="#" className="hover:text-primary transition-colors">INSTAGRAM</a>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-transparent bg-secondary backdrop-blur-md border-border/40 py-3 shadow-sm">
        <div className="container flex justify-between items-center">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-2 group cursor-pointer">
              <img 
                src="/logo-header.png" 
                srcSet="/logo-header@2x.png 2x"
                alt="Oakridge Construction" 
                className="h-14 md:h-16 w-auto object-contain group-hover:opacity-80 transition-opacity"
              />
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link key={link.name} href={link.href}>
                <span
                  className={cn(
                    "text-sm font-medium uppercase tracking-widest hover:text-primary transition-colors relative after:content-[''] after:absolute after:-bottom-1 after:left-0 after:w-0 after:h-[2px] after:bg-primary after:transition-all hover:after:w-full cursor-pointer",
                    location === link.href ? "text-primary after:w-full" : "text-white"
                  )}
                >
                  {link.name}
                </span>
              </Link>
            ))}
            <Link href="/contact">
              <Button variant="default" size="sm" className="rounded-none font-display tracking-wide text-sm h-10 px-6 bg-primary hover:bg-primary/90 text-primary-foreground shadow-none border-none">
                GET A QUOTE
              </Button>
            </Link>
          </nav>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-background pt-24 px-6 md:hidden animate-in slide-in-from-top-10 fade-in duration-200">
          <nav className="flex flex-col gap-6 text-center">
            {navLinks.map((link) => (
              <Link key={link.name} href={link.href}>
                <span
                  className={cn(
                    "text-2xl font-display uppercase tracking-wider hover:text-primary transition-colors cursor-pointer",
                    location === link.href ? "text-primary" : "text-foreground"
                  )}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </span>
              </Link>
            ))}
            <Link href="/contact">
              <Button className="w-full mt-6 rounded-none bg-primary text-white hover:bg-primary/90 font-display tracking-wide uppercase h-12">
                GET A QUOTE
              </Button>
            </Link>
          </nav>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-secondary text-white">
        <div className="container py-20">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            {/* Brand */}
            <div>
              <img 
                src="/logo-footer.png" 
                srcSet="/logo-footer@2x.png 2x"
                alt="Oakridge Construction" 
                className="h-24 w-auto object-contain mb-6"
              />
              <p className="text-gray-400 text-sm leading-relaxed">
                Building legacy through precision. Premium residential and commercial construction services across Massachusetts.
              </p>
            </div>

            <div>
              <h4 className="text-white font-display text-lg mb-6 uppercase tracking-wider">Quick Links</h4>
              <ul className="space-y-3 text-sm font-mono text-muted-foreground">
                <li><Link href="/"><span className="hover:text-primary transition-colors cursor-pointer">HOME</span></Link></li>
                <li><Link href="/about"><span className="hover:text-primary transition-colors cursor-pointer">ABOUT US</span></Link></li>
                <li><Link href="/services"><span className="hover:text-primary transition-colors cursor-pointer">SERVICES</span></Link></li>
                <li><Link href="/projects"><span className="hover:text-primary transition-colors cursor-pointer">PROJECTS</span></Link></li>
                <li><Link href="/blog"><span className="hover:text-primary transition-colors cursor-pointer">BLOG</span></Link></li>
                <li><Link href="/contact"><span className="hover:text-primary transition-colors cursor-pointer">CONTACT</span></Link></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-display text-lg mb-6 uppercase tracking-wider">Services</h4>
              <ul className="space-y-3 text-sm font-mono text-muted-foreground">
                <li><span className="hover:text-primary transition-colors cursor-pointer">Home Remodeling</span></li>
                <li><span className="hover:text-primary transition-colors cursor-pointer">Kitchen & Bath</span></li>
                <li><span className="hover:text-primary transition-colors cursor-pointer">Commercial</span></li>
                <li><span className="hover:text-primary transition-colors cursor-pointer">Flooring</span></li>
                <li><span className="hover:text-primary transition-colors cursor-pointer">Painting</span></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-display text-lg mb-6 uppercase tracking-wider">Contact</h4>
              <div className="space-y-4 text-sm">
                <div className="flex items-start gap-3">
                  <Phone className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-mono text-primary">(617) 555-0123</p>
                    <p className="text-gray-400 text-xs">Mon-Fri: 8am-6pm</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Mail className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                  <p className="font-mono text-gray-400">info@kridstruct.com</p>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                  <p className="text-gray-400">Massachusetts</p>
                </div>
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="py-8 border-t border-white/10 flex justify-between items-center">
            <p className="text-xs font-mono text-gray-500">© 2024 Oakridge Construction. All rights reserved.</p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
