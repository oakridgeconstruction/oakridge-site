export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  category: string;
  image: string;
  readTime: number;
}

export const articles: Article[] = [
  {
    id: "1",
    title: "The Complete Guide to Kitchen Remodeling",
    excerpt: "Transform your kitchen into a modern culinary space. Learn about layout optimization, material selection, and budgeting.",
    content: `
      <h2>Introduction</h2>
      <p>A kitchen remodel is one of the most impactful renovations you can make to your home. Not only does it improve functionality and aesthetics, but it can also significantly increase your home's value.</p>
      
      <h2>Planning Your Kitchen Remodel</h2>
      <p>Before breaking down walls or selecting finishes, take time to plan your project thoroughly. Consider your lifestyle, cooking habits, and long-term goals for the space.</p>
      
      <h3>Layout Optimization</h3>
      <p>The kitchen work triangle—connecting the sink, stove, and refrigerator—remains a fundamental design principle. Ensure these three elements are positioned efficiently to minimize unnecessary movement.</p>
      
      <h3>Material Selection</h3>
      <p>Choose durable, high-quality materials that align with your design vision and budget. Granite and quartz countertops offer longevity, while hardwood cabinets provide timeless appeal.</p>
      
      <h2>Budget Considerations</h2>
      <p>Kitchen remodels typically range from $50,000 to $150,000+ depending on scope. Allocate funds strategically: prioritize quality where it matters most (cabinets, countertops) and save where possible.</p>
      
      <h2>Timeline</h2>
      <p>A typical kitchen remodel takes 6-12 weeks. Factor in design time, permitting, material ordering, and construction. Delays are common, so build in buffer time.</p>
    `,
    author: "John Smith",
    date: "2024-11-15",
    category: "Kitchen Remodeling",
    image: "/service-remodeling.jpg",
    readTime: 8
  },
  {
    id: "2",
    title: "Bathroom Renovation Trends for 2024",
    excerpt: "Discover the latest bathroom design trends including spa-like features, sustainable materials, and smart technology integration.",
    content: `
      <h2>Modern Bathroom Design Trends</h2>
      <p>Bathroom design has evolved significantly in recent years. Today's bathrooms are more than functional spaces—they're personal sanctuaries designed for relaxation and wellness.</p>
      
      <h2>Spa-Like Features</h2>
      <p>Homeowners increasingly invest in spa-inspired elements: rainfall showerheads, heated floors, soaking tubs, and ambient lighting. These features create a luxury resort experience at home.</p>
      
      <h2>Sustainable Materials</h2>
      <p>Eco-conscious design is no longer optional. Recycled glass tiles, sustainable wood, low-flow fixtures, and water-efficient toilets appeal to environmentally aware homeowners.</p>
      
      <h2>Smart Technology</h2>
      <p>Smart mirrors, heated towel racks, and automated lighting systems are becoming standard. These technologies enhance convenience and energy efficiency.</p>
      
      <h2>Color Palettes</h2>
      <p>Neutral tones remain popular, but bold accent colors are gaining traction. Deep blues, forest greens, and warm terracottas add personality without overwhelming the space.</p>
    `,
    author: "Sarah Johnson",
    date: "2024-11-10",
    category: "Bathroom Renovation",
    image: "/service-remodeling.jpg",
    readTime: 6
  },
  {
    id: "3",
    title: "Home Safety: Essential Compliance Standards",
    excerpt: "Understanding building codes and safety standards ensures your renovation meets all legal requirements and protects your family.",
    content: `
      <h2>Why Building Codes Matter</h2>
      <p>Building codes exist to protect occupants and ensure structural integrity. They cover everything from electrical systems to fire safety to accessibility requirements.</p>
      
      <h2>Common Code Requirements</h2>
      <p>Electrical work must be performed by licensed electricians. Plumbing must meet specific standards for water pressure and drainage. Structural modifications require engineering approval.</p>
      
      <h2>Permits and Inspections</h2>
      <p>Most renovations require permits. While this adds time and cost, inspections ensure work meets standards. Never skip the permitting process—it protects you legally and financially.</p>
      
      <h2>Working with Professionals</h2>
      <p>Licensed contractors understand local codes and handle permitting. This expertise prevents costly mistakes and ensures your renovation adds value rather than liability.</p>
    `,
    author: "Michael Brown",
    date: "2024-11-05",
    category: "Safety & Compliance",
    image: "/hero-construction.jpg",
    readTime: 7
  },
  {
    id: "4",
    title: "Commercial Construction Best Practices",
    excerpt: "Explore proven strategies for successful commercial projects including project management, timeline optimization, and team coordination.",
    content: `
      <h2>Project Management Excellence</h2>
      <p>Commercial projects demand rigorous project management. Clear communication, detailed timelines, and regular progress tracking prevent costly delays.</p>
      
      <h2>Timeline Optimization</h2>
      <p>Coordinating multiple trades requires careful scheduling. Sequencing work properly—foundation before framing, rough-ins before drywall—keeps projects on track.</p>
      
      <h2>Team Coordination</h2>
      <p>Success depends on seamless coordination between architects, engineers, contractors, and subcontractors. Regular meetings and clear protocols prevent miscommunication.</p>
      
      <h2>Quality Assurance</h2>
      <p>Continuous quality checks throughout construction catch issues early. Final inspections ensure the completed project meets specifications and codes.</p>
    `,
    author: "David Martinez",
    date: "2024-10-28",
    category: "Commercial Construction",
    image: "/service-commercial.jpg",
    readTime: 9
  }
];

export const categories = Array.from(new Set(articles.map(a => a.category)));
