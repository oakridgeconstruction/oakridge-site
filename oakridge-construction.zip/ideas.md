# Brainstorm de Design: Oakridge Construction

<response>
<probability>0.08</probability>
<text>
## Abordagem 1: "A Estrutura Exposta" (Industrial Refinado)

**Movimento de Design:** Brutalismo Suave / Estética Industrial Contemporânea.

**Princípios Centrais:**
1.  **Honestidade Material:** O design reflete a construção real — sólido, estrutural e sem adornos desnecessários.
2.  **Contraste de Escala:** Uso de tipografia massiva contra detalhes finos para criar tensão visual.
3.  **Precisão Técnica:** Linhas de grade visíveis e elementos que lembram plantas arquitetônicas.

**Filosofia de Cores:**
*   **Base:** "Concreto Polido" (Cinza muito claro e frio) e "Aço Escuro" (Carvão quase preto).
*   **Destaque:** "Laranja de Segurança Elevado" (Um laranja queimado, vibrante mas maduro) — usado com parcimônia para guiar o olhar, remetendo a equipamentos de alta qualidade e segurança.
*   **Intenção:** Transmitir força, durabilidade e a natureza "mão na massa" do negócio, mas com um acabamento de luxo.

**Paradigma de Layout:**
*   **Modular Assimétrico:** Blocos de conteúdo que se sobrepõem ligeiramente, quebrando a rigidez da grade tradicional.
*   **Divisões Claras:** Uso de linhas finas (1px) para separar seções, lembrando vigas e colunas.

**Elementos de Assinatura:**
*   Números grandes (01, 02, 03) para listas e passos, em fonte stencil ou técnica.
*   Imagens com tratamento de alto contraste e leve granulação.
*   Botões retangulares com bordas afiadas (sem arredondamento), transmitindo precisão.

**Filosofia de Interação:**
*   Interações "pesadas" e satisfatórias. O hover nos botões é instantâneo e sólido, sem transições suaves demais.
*   Scroll com "snap" suave em seções principais para dar peso a cada conteúdo.

**Animação:**
*   Revelação de elementos estilo "construção": blocos de texto deslizam de baixo para cima como se estivessem sendo erguidos.
*   Linhas da grade desenham-se ao carregar a página.

**Sistema Tipográfico:**
*   **Títulos:** *Oswald* ou *Teko* (Sans-serif condensada, alta e forte) — para manchetes que ocupam espaço.
*   **Corpo:** *Roboto Mono* (para dados técnicos) misturado com *Archivo* (para texto de leitura), criando um ar técnico e moderno.
</text>
</response>

<response>
<probability>0.06</probability>
<text>
## Abordagem 2: "O Arquiteto Silencioso" (Minimalismo de Luxo)

**Movimento de Design:** Minimalismo Escandinavo / Modernismo de Galeria.

**Princípios Centrais:**
1.  **O Espaço é Luxo:** Uso agressivo de espaço em branco (negativo) para emoldurar o conteúdo como obra de arte.
2.  **Foco na Fotografia:** As imagens dos projetos são os heróis absolutos, ocupando grandes áreas da tela sem obstruções.
3.  **Sutileza e Elegância:** Nada grita; tudo sussurra qualidade e acabamento premium.

**Filosofia de Cores:**
*   **Base:** "Branco Papel" e "Areia Quente" (Beige muito sutil).
*   **Destaque:** "Ouro Envelhecido" (Metálico fosco) e "Preto Tinta".
*   **Intenção:** Evocar a sensação de entrar em uma casa recém-construída de alto padrão: limpa, iluminada e sofisticada.

**Paradigma de Layout:**
*   **Broken Grid (Grade Quebrada):** Elementos flutuam livremente, ignorando alinhamentos óbvios para criar interesse visual orgânico.
*   **Sobreposição de Texto e Imagem:** Títulos elegantes sobrepondo partes das imagens de forma editorial.

**Elementos de Assinatura:**
*   Linhas verticais sutis que percorrem toda a página, guiando o scroll.
*   Uso de máscaras de imagem não convencionais (retângulos muito verticais ou horizontais).
*   Ícones de linha ultra-finos.

**Filosofia de Interação:**
*   Fluida e etérea. O mouse provoca mudanças sutis de opacidade ou deslocamento lento (parallax).
*   Cursor personalizado (um círculo fino) que reage magneticamente aos elementos clicáveis.

**Animação:**
*   Fade-ins lentos e elegantes.
*   Imagens com efeito de zoom muito lento (Ken Burns effect) ao aparecerem.

**Sistema Tipográfico:**
*   **Títulos:** *Playfair Display* ou *Cinzel* (Serifada de alto contraste) — transmite tradição e elegância atemporal.
*   **Corpo:** *Lato* ou *Mulish* (Sans-serif geométrica leve) — para legibilidade cristalina e moderna.
</text>
</response>

<response>
<probability>0.09</probability>
<text>
## Abordagem 3: "O Construtor Americano" (Confiança Corporativa Moderna)

**Movimento de Design:** Estilo Corporativo Americano Moderno (Swiss Style atualizado).

**Princípios Centrais:**
1.  **Clareza e Autoridade:** Informação apresentada de forma direta, sem ambiguidades. "Nós construímos, nós entregamos".
2.  **Hierarquia Forte:** Tamanhos de fonte e pesos claramente definidos para guiar a leitura rápida.
3.  **Confiança Visual:** Uso de formas sólidas e cores que inspiram segurança e estabilidade.

**Filosofia de Cores:**
*   **Base:** "Azul Marinho Profundo" (Navy Blue - autoridade) e "Branco Puro".
*   **Destaque:** "Amarelo Ocre" (não neon, um amarelo terra) para CTAs e destaques importantes.
*   **Intenção:** A paleta clássica da construção americana, mas modernizada. Transmite: "Somos estabelecidos, seguros e profissionais".

**Paradigma de Layout:**
*   **Bento Grid / Cards:** Conteúdo organizado em cartões e blocos bem definidos, facilitando a digestão da informação.
*   **Seções de Largura Total:** Alternância entre fundos brancos e fundos escuros (Navy) para segmentar o conteúdo claramente.

**Elementos de Assinatura:**
*   Barra de progresso ou indicadores visuais de "etapas" (Planejamento -> Construção -> Entrega).
*   Fotografia com pessoas (trabalhadores, clientes felizes) para humanizar a marca.
*   Sombras suaves (drop shadows) para dar profundidade aos cards sobre o fundo branco.

**Filosofia de Interação:**
*   Responsiva e tátil. Botões mudam de cor claramente ao hover.
*   Feedback visual imediato em formulários e ações.

**Animação:**
*   Transições laterais (slide-in) nítidas e rápidas.
*   Contadores numéricos animados para estatísticas (ex: "150+ Projetos Entregues").

**Sistema Tipográfico:**
*   **Títulos:** *Montserrat* ou *Barlow* (Sans-serif geométrica robusta) — em negrito (Bold/Black) para máximo impacto.
*   **Corpo:** *Open Sans* ou *Inter* (mas com pesos variados) — neutra, legível e familiar.
</text>
</response>
